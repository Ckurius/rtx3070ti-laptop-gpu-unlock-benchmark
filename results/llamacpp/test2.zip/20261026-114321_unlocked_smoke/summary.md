# llama.cpp run 20261026-114321_unlocked_smoke

- Phase **unlocked**, gpu_unlock state **unlocked**
- llama.cpp fd8f8451a 2026-10-26 tests : refactor test-llama-archs to not link internal libllama symbols (#30880)
- Duration 0.6 min

| Test | Expect | Median tokens/s | CV % | n | Avg W | Max °C | Status |
|---|---|---:|---:|---:|---:|---:|---|
| BF16_pp512_fa-off | gain | 4648.4 | 0.7 | 2 | 29.1 | 53 | ok |
| BF16_tg32_fa-off | control | 52.2 | 0.2 | 2 | 61.8 | 55 | ok |
| BF16_pp512_fa-on | gain | 5160.5 | 0.6 | 2 | 47.2 | 55 | ok |
| BF16_tg32_fa-on | control | 53.0 | 0.2 | 2 | 55.2 | 56 | ok |
| F16_pp512_fa-off | info | 4733.5 | 0.4 | 2 | 39.6 | 56 | ok |
| F16_tg32_fa-off | control | 52.4 | 0.3 | 2 | 55.8 | 57 | ok |
| F16_pp512_fa-on | info | 5115.1 | 0.2 | 2 | 54.6 | 56 | ok |
| F16_tg32_fa-on | control | 53.2 | 0.2 | 2 | 57.3 | 57 | ok |
| Q8_0_pp512_fa-off | info | 5040.2 | 0.0 | 2 | 45.0 | 55 | ok |
| Q8_0_tg32_fa-off | control | 90.1 | 0.2 | 2 | 62.4 | 57 | ok |
| Q8_0_pp512_fa-on | info | 5718.0 | 0.6 | 2 | 68.8 | 57 | ok |
| Q8_0_tg32_fa-on | control | 93.0 | 0.1 | 2 | 54.1 | 57 | ok |
| Q4_K_M_pp512_fa-off | info | 4766.1 | 0.6 | 2 | 52.9 | 57 | ok |
| Q4_K_M_tg32_fa-off | control | 131.4 | 0.2 | 2 | 43.9 | 57 | ok |
| Q4_K_M_pp512_fa-on | info | 5349.0 | 1.2 | 2 | 70.0 | 57 | ok |
| Q4_K_M_tg32_fa-on | control | 136.3 | 0.4 | 2 | 62.1 | 58 | ok |
